#ifndef BEZIER_HPP
#define BEZIER_HPP

#include <iostream>
#include <assert.h>
#include <math.h>

template<typename T>
class bezier{
public:
	bezier();
	bezier(T const&, T const&, T const&, T const&);

	// Setter
	T& coeff(int const);

	// Getter
	T const& coeff(int const) const;

	// Retourne le resultat de l'equation de bezier associee aux coefficients
	T operator()(float s) const;
protected:

private:
	// Contient les coefficients de la courbe de bezier
	T coefficients[4];
};

// Affiche l'equation de la courbe
template<typename T>
std::ostream& operator<<(std::ostream& os, bezier<T> const& b);

template<typename T>
bezier<T>::bezier(){
	
}

template<typename T>
bezier<T>::bezier(T const& c1, T const& c2, T const& c3, T const& c4){
	coefficients[0] = c1;
	coefficients[1] = c2;
	coefficients[2] = c3;
	coefficients[3] = c4;
}

template<typename T>
T& bezier<T>::coeff(int const i){
	// Verification si on cherche un coefficient possible
	assert((i > 0) || (i < 3)); // ????
	return coefficients[i];
}

template<typename T>
T const& bezier<T>::coeff(int const i) const{
	// Même chose qu'avant
	assert((i > 0) || (i < 3));
	return coefficients[i];
}

template<typename T>
T bezier<T>::operator()(float s) const{
	// Retourne le resultat de l'equation de bezier
	return 	pow(1.f - s, 3.f) * coefficients[0]
			+ 3.f * pow(1.f - s, 2.f) * s * coefficients[1]
			+ 3.f * (1.f - s) * s * s * coefficients[2]
			+ pow(s, 3.f) * coefficients[3];
}

template<typename T>
std::ostream& operator<<(std::ostream& os, bezier<T> const& b){
	// Permet d'afficher l'equation de bezier
	os<< "(1-s)^3*"<< b.coeff(0) << "+3s(1-s)^2*"<< b.coeff(1)<< "+3s^2(1-s)*"<< b.coeff(2)<< "+s^3*"<< b.coeff(3)<< std::endl;
	return os;
}
#endif