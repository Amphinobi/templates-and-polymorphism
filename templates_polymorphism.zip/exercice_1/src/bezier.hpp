#pragma once

#ifndef BEZIER_HPP
#define BEZIER_HPP

#include <iostream>

class bezier{
public:
	bezier() = default;
	bezier(float const&, float const&, float const&, float const&);

	// Setter
	float& coeff(int const);

	// Getter
	float const& coeff(int const) const;

	// Retourne le resultat de l'equation de bezier associee aux coefficients
	float operator()(float const&) const;
protected:

private:
	// Contient les coefficients de la courbe de bezier
	float coefficients[4];
};

// Affiche l'equation de la courbe
std::ostream& operator<<(std::ostream& os, bezier const& b);

#endif