#include "bezier.hpp"
#include <assert.h>
#include <math.h>

bezier::bezier(float const& c1, float const& c2, float const& c3, float const& c4){
	coefficients[0] = c1;
	coefficients[1] = c2;
	coefficients[2] = c3;
	coefficients[3] = c4;
}

float& bezier::coeff(int const i){
	// Verification si on cherche un coefficient possible
	assert((i > 0) || (i < 3));
	return coefficients[i];
}

float const& bezier::coeff(int const i) const{
	// Même chose qu'avant
	assert((i > 0) || (i < 3));
	return coefficients[i];
}

float bezier::operator()(float const& s) const{
	// Retourne le resultat de l'equation de bezier
	return 	pow(1.f - s, 3.f) * coefficients[0]
			+ 3.f * pow(1.f - s, 2.f) * s * coefficients[1]
			+ 3.f * (1.f - s) * s * s * coefficients[2]
			+ pow(s, 3.f) * coefficients[3];
}

std::ostream& operator<<(std::ostream& os, bezier const& b){
	// Permet d'afficher l'equation de bezier
	os<< "(1-s)^3*"<< b.coeff(0) << "+3s(1-s)^2*"<< b.coeff(1)<< "+3s^2(1-s)*"<< b.coeff(2)<< "+s^3*"<< b.coeff(3)<< std::endl;
	return os;
}